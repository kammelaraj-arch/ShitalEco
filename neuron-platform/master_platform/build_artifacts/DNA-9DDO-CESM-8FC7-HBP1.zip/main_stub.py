"""
Auto-generated firmware bootstrap for Neuron Platform.
Loads dna.json, brain.json and pinmap.json, then enters main.py from /level0-pico2w.
"""
import json, sys

with open("dna.json") as fh:
    DNA = json.load(fh)
with open("brain.json") as fh:
    BRAIN = json.load(fh)
with open("pinmap.json") as fh:
    PINMAP = json.load(fh)

print("[neuron] booted", DNA["device_dna"], "fw", DNA["base_firmware_version"])
